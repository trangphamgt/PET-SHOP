﻿using AutoMapper;
using System;

namespace BoosShop.Common
{
    public class Mapping
    {
        
    }
}
