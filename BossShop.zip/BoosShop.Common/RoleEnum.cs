﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BOSS.Common
{
    public enum RoleEnum
    {
        Admin = 1,
        User = 0,
        Both = 2,
    }
}
