﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BOSS.Common
{
    
        public enum StatusEnum
        {
            Success = 1,
            Failure = -1,
        }
    
}
